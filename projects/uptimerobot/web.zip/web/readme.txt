modify /php/config.php
Add your API